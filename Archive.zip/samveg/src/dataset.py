import torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer
import pandas as pd

class CompanyClassificationDataset(Dataset):
    def __init__(self, data: pd.DataFrame, config: ModelConfig, is_training: bool = True):
        self.data = data
        self.tokenizer = AutoTokenizer.from_pretrained(config.base_model_name)
        self.config = config
        self.is_training = is_training
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        row = self.data.iloc[idx]
        
        # Combine all text information
        text = f"Company: {row['company_name']} \n"
        text += f"Scrapped Info: {row['scrapped_info']} \n"
        text += f"Search Info: {row['search_info']}"
        
        # Tokenize
        encoding = self.tokenizer(
            text,
            max_length=self.config.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        item = {
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
        }
        
        if self.is_training:
            item['label'] = torch.tensor(row['label'], dtype=torch.long)
            
        return item 