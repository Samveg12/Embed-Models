import torch
from torch.utils.data import DataLoader
from torch.optim import AdamW
import torch.nn.functional as F
from tqdm import tqdm
from sklearn.metrics import classification_report

class Trainer:
    def __init__(self, model, config: ModelConfig):
        self.model = model
        self.config = config
        self.device = torch.device(config.device)
        self.model.to(self.device)
        
    def get_loss_function(self):
        if self.config.loss_function == "cross_entropy":
            return F.cross_entropy
        elif self.config.loss_function == "focal_loss":
            def focal_loss(pred, target, gamma=2.0, alpha=0.25):
                ce_loss = F.cross_entropy(pred, target, reduction='none')
                pt = torch.exp(-ce_loss)
                focal_loss = alpha * (1-pt)**gamma * ce_loss
                return focal_loss.mean()
            return focal_loss
        else:
            raise ValueError(f"Unknown loss function: {self.config.loss_function}")
    
    def train(self, train_loader: DataLoader, val_loader: DataLoader):
        optimizer = AdamW(self.model.parameters(), lr=self.config.learning_rate)
        loss_fn = self.get_loss_function()
        
        best_val_loss = float('inf')
        
        for epoch in range(self.config.num_epochs):
            # Training
            self.model.train()
            train_loss = 0
            
            for batch in tqdm(train_loader, desc=f"Epoch {epoch+1}/{self.config.num_epochs}"):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['label'].to(self.device)
                
                optimizer.zero_grad()
                outputs = self.model(input_ids, attention_mask)
                loss = loss_fn(outputs, labels)
                loss.backward()
                optimizer.step()
                
                train_loss += loss.item()
            
            # Validation
            val_loss, val_metrics = self.evaluate(val_loader)
            
            print(f"Epoch {epoch+1}")
            print(f"Train Loss: {train_loss/len(train_loader):.4f}")
            print(f"Val Loss: {val_loss:.4f}")
            print("Validation Metrics:")
            print(val_metrics)
            
            # Save best model
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                torch.save(self.model.state_dict(), 'best_model.pt')
    
    def evaluate(self, data_loader: DataLoader):
        self.model.eval()
        loss_fn = self.get_loss_function()
        total_loss = 0
        all_preds = []
        all_labels = []
        
        with torch.no_grad():
            for batch in data_loader:
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['label'].to(self.device)
                
                outputs = self.model(input_ids, attention_mask)
                loss = loss_fn(outputs, labels)
                total_loss += loss.item()
                
                preds = torch.argmax(outputs, dim=1)
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
        
        metrics = classification_report(all_labels, all_preds, output_dict=True)
        return total_loss/len(data_loader), metrics 