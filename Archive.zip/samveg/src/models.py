from src.config import ModelConfig
import torch
import torch.nn as nn
from transformers import AutoModel
import torch.nn.functional as F

class LinearClassifier(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.config = config
        
        # Load base embedding model
        self.base_model = AutoModel.from_pretrained(config.base_model_name)
        
        # Freeze base model if needed
        for param in self.base_model.parameters():
            param.requires_grad = False
            
        # Linear classifier
        self.classifier = nn.Linear(self.base_model.config.hidden_size, config.num_classes)
        
    def forward(self, input_ids, attention_mask):
        # Get embeddings
        outputs = self.base_model(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        
        # Use CLS token embedding
        pooled_output = outputs.last_hidden_state[:, 0]
        
        # Classification
        logits = self.classifier(pooled_output)
        return logits

class TransformerClassifier(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.config = config
        
        # Load base embedding model
        self.base_model = AutoModel.from_pretrained(config.base_model_name)
        
        # Freeze base model if needed
        for param in self.base_model.parameters():
            param.requires_grad = False
            
        # Additional transformer layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.transformer_dim,
            nhead=config.transformer_num_heads,
            dropout=config.transformer_dropout
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=config.transformer_num_layers
        )
        
        # Linear classifier
        self.classifier = nn.Linear(config.transformer_dim, config.num_classes)
        
    def forward(self, input_ids, attention_mask):
        # Get embeddings
        outputs = self.base_model(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        
        # Transform sequence
        sequence_output = outputs.last_hidden_state
        transformed = self.transformer(sequence_output)
        
        # Pool and classify
        pooled_output = transformed.mean(dim=1)  # Mean pooling
        logits = self.classifier(pooled_output)
        return logits 