from dataclasses import dataclass
from typing import Optional, List

@dataclass
class ModelConfig:
    base_model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    num_classes: int = 19  # 18 categories + 1 for "Doesn't belong to any"
    max_length: int = 512
    batch_size: int = 32
    learning_rate: float = 2e-5
    num_epochs: int = 10
    device: str = "cuda"  # or "cpu"
    loss_function: str = "cross_entropy"  # or "focal_loss"
    model_type: str = "linear"  # or "transformer"
    
    # Transformer specific configs
    transformer_num_layers: int = 2
    transformer_num_heads: int = 8
    transformer_dim: int = 384  # Should match base model hidden size
    transformer_dropout: float = 0.1 