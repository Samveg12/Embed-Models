import pandas as pd
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split

from config import ModelConfig
from dataset import CompanyClassificationDataset
from models import LinearClassifier, TransformerClassifier
from trainer import Trainer

def main():
    # Load configuration
    config = ModelConfig()
    
    # Load and preprocess data
    # Assuming your data is in a CSV file with columns:
    # company_name, scrapped_info, search_info, label
    data = pd.read_csv('your_data.csv')
    
    # Split data
    train_data, val_data = train_test_split(data, test_size=0.2, random_state=42)
    
    # Create datasets
    train_dataset = CompanyClassificationDataset(train_data, config)
    val_dataset = CompanyClassificationDataset(val_data, config)
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.batch_size,
        shuffle=False
    )
    
    # Initialize model based on config
    if config.model_type == "linear":
        model = LinearClassifier(config)
    else:
        model = TransformerClassifier(config)
    
    # Initialize trainer and train
    trainer = Trainer(model, config)
    trainer.train(train_loader, val_loader)

if __name__ == "__main__":
    main() 