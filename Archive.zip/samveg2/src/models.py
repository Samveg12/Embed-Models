from autogluon.tabular import TabularPredictor
from autogluon.multimodal import MultiModalPredictor
from src.config import ModelConfig
from transformers import AutoModel
import torch.nn as nn
import torch

class LinearClassifier(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.base_model = AutoModel.from_pretrained(config.embedding_model)
        self.classifier = nn.Linear(self.base_model.config.hidden_size, config.num_classes)
        
    def forward(self, input_ids, attention_mask):
        outputs = self.base_model(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0]  # Use [CLS] token
        return self.classifier(pooled_output)

def create_autogluon_linear_classifier(config: ModelConfig, train_data: pd.DataFrame):
    """Create AutoGluon model with linear classifier"""
    predictor = TabularPredictor(
        label='label',
        problem_type='multiclass',
        eval_metric='accuracy'
    )
    
    # Configure model parameters
    hyperparameters = {
        'model': 'transformer',
        'transformer.text_backbone': config.embedding_model,
        'transformer.max_length': config.max_length,
        'transformer.learning_rate': config.learning_rate,
        'transformer.optimizer.params.lr': config.learning_rate,
        'transformer.epochs': config.num_epochs,
        'transformer.batch_size': config.batch_size,
    }
    
    predictor.fit(
        train_data=train_data,
        hyperparameters=hyperparameters,
        time_limit=3600  # 1 hour time limit
    )
    
    return predictor

def create_autogluon_transformer_classifier(config: ModelConfig, train_data: pd.DataFrame):
    """Create AutoGluon model with transformer + linear classifier"""
    predictor = MultiModalPredictor(
        label='label',
        problem_type='multiclass',
        eval_metric='accuracy'
    )
    
    # Configure model parameters
    hyperparameters = {
        'model.names': ['transformer'],
        'model.transformer.text_backbone': config.embedding_model,
        'optimization.learning_rate': config.learning_rate,
        'optimization.max_epochs': config.num_epochs,
        'optimization.batch_size': config.batch_size,
        'optimization.loss_function': config.loss_function,
    }
    
    predictor.fit(
        train_data=train_data,
        hyperparameters=hyperparameters,
        time_limit=3600  # 1 hour time limit
    )
    
    return predictor 