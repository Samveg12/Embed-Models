from config import ModelConfig, DataConfig
from data_processor import prepare_data
from models import create_autogluon_linear_classifier, create_autogluon_transformer_classifier
import logging
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_type', type=str, choices=['linear', 'transformer'], 
                       default='transformer', help='Type of model to train')
    args = parser.parse_args()
    
    # Initialize configs
    model_config = ModelConfig()
    data_config = DataConfig()
    
    # Prepare data
    data_dict = prepare_data(data_config)
    
    # Train model
    if args.model_type == 'linear':
        predictor = create_autogluon_linear_classifier(model_config, data_dict['train'])
    else:
        predictor = create_autogluon_transformer_classifier(model_config, data_dict['train'])
    
    # Evaluate if validation data exists
    if 'val' in data_dict:
        metrics = predictor.evaluate(data_dict['val'])
        print(f"Validation metrics: {metrics}")
    
    # Save model
    predictor.save(f'models/{args.model_type}_classifier')

if __name__ == "__main__":
    main() 