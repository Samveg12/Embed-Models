from dataclasses import dataclass
from typing import Optional

@dataclass
class ModelConfig:
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    max_length: int = 512
    num_classes: int = 19  # 18 categories + 1 for "Doesn't belong to any"
    learning_rate: float = 2e-5
    batch_size: int = 16
    num_epochs: int = 10
    loss_function: str = "cross_entropy"  # Options: cross_entropy, focal_loss
    device: str = "cuda"  # or "cpu"
    
@dataclass
class DataConfig:
    train_data_path: str = "data/train.csv"
    val_data_path: Optional[str] = "data/val.csv"
    test_data_path: Optional[str] = "data/test.csv" 