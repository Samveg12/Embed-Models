import pandas as pd
import torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer
from typing import List, Dict, Union
import numpy as np

class CompanyDataset(Dataset):
    def __init__(self, 
                 data: pd.DataFrame, 
                 tokenizer_name: str,
                 max_length: int = 512):
        self.data = data
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        self.max_length = max_length
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        row = self.data.iloc[idx]
        
        # Combine all text information
        text = f"Company: {row['company_name']} \n"
        text += f"Scrapped Info: {row['scrapped_info']} \n"
        text += f"Search Info: {row['search_info']}"
        
        # Tokenize
        encoding = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
            'labels': torch.tensor(row['label'], dtype=torch.long)
        }

def prepare_data(config: DataConfig) -> Dict[str, pd.DataFrame]:
    """Load and prepare the data"""
    train_df = pd.read_csv(config.train_data_path)
    
    # Convert categories to numerical labels
    label_map = {cat: idx for idx, cat in enumerate(train_df['label'].unique())}
    train_df['label'] = train_df['label'].map(label_map)
    
    data_dict = {'train': train_df}
    
    if config.val_data_path:
        val_df = pd.read_csv(config.val_data_path)
        val_df['label'] = val_df['label'].map(label_map)
        data_dict['val'] = val_df
        
    if config.test_data_path:
        test_df = pd.read_csv(config.test_data_path)
        test_df['label'] = test_df['label'].map(label_map)
        data_dict['test'] = test_df
        
    return data_dict 